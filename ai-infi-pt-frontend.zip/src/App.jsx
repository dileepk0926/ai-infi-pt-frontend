import React from "react";

function App() {
  return (
    <div className="p-6 text-center text-xl text-blue-600">
      <h1>AI INFI PT - Web Version</h1>
    </div>
  );
}

export default App;
